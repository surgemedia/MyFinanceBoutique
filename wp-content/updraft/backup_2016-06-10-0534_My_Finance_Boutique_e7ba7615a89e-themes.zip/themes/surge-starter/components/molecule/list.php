<?php //debug($vars) ?>
<div class="<?php echo $vars['class'] ?> list molecule">
<h1><?php if($vars['title']){ echo $vars['title']; } ?></h1>
<ul>
	<?php for ($vars['i']=0; $vars['i'] < sizeof($vars['list']); $vars['i']++) { ?>
		<li><?php echo $vars['list'][$vars['i']]['list_text'] ?></li>
	<?php } ?>
</ul>	
</div>