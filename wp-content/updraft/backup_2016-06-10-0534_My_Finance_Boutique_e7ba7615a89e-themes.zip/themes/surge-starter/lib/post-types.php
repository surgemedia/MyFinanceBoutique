 <?php 
/*============================================
	=          Testimonial - Post Type           =
	============================================*/
	$testimonial = new CPT([
	    'post_type_name' => 'testimonial',
	]);
	$testimonial->menu_icon("dashicons-format-quote");
?>